/*
这节课涉及到前后端的完整通信, 我们自己同时运行前端项目和后端项目
1. 先运行 todo_api 项目, 注意, todo_api 提供后端 api 服务
1) 先切换到 todo_api 根目录下
2) 执行 yarn install 按照依赖
3) 执行 yarn run start 运行项目

2. 再使用 webstorm 运行 todo_react 项目
1) 先切换到 todo_react 根目录下
2) 执行 yarn install 按照依赖
3) 执行 yarn run start 运行项目
*/
