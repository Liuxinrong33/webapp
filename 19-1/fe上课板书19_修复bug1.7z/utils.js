const log = console.log.bind(console)

module.exports = {
    log: log,
}